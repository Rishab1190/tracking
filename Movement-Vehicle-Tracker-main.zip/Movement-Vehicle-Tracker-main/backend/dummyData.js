const dummyData = [
    { "latitude": 17.385044, "longitude": 78.486671, "timestamp": "2024-07-20T10:00:00Z" },
    { "latitude": 17.385045, "longitude": 78.486672, "timestamp": "2024-07-20T10:00:05Z" },
    { "latitude": 17.386000, "longitude": 78.486673, "timestamp": "2024-07-20T10:00:10Z" },
    { "latitude": 17.387000, "longitude": 78.486674, "timestamp": "2024-07-20T10:00:15Z" },
    { "latitude": 17.388000, "longitude": 78.486675, "timestamp": "2024-07-20T10:00:20Z" },
];

export default dummyData;